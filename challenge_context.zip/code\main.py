import csv
import json
from pathlib import Path
from datetime import datetime, timezone


ROOT = Path(__file__).resolve().parents[1]
DATASET = ROOT / "dataset"
EVIDENCE_ROOT = DATASET / "evidence"


def read_csv(filename):
    """Read a UTF-8 CSV file from the dataset directory."""
    path = DATASET / filename

    with path.open("r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def parse_time(value):
    """Parse an ISO-8601 timestamp, including timestamps ending in Z."""
    if not value:
        return None

    value = value.strip().replace("Z", "+00:00")
    result = datetime.fromisoformat(value)

    if result.tzinfo is None:
        result = result.replace(tzinfo=timezone.utc)

    return result.astimezone(timezone.utc)


def normalize_email(value):
    return (value or "").strip().casefold()


def load_data():
    return {
        "requests": read_csv("deletion_requests.csv"),
        "identities": read_csv("user_identities.csv"),
        "audit": read_csv("user_audit_log.csv"),
        "activities": read_csv("system_activity.csv"),
        "rules": read_csv("deletion_rules.csv"),
        "manifest": read_csv("evidence_files.csv"),
    }


def resolve_identity(request, identities, audit):
    """
    Resolve the request email to a user ID using the identity snapshot
    and email changes recorded no later than the audit cutoff.

    Returns a user ID only when the available evidence identifies one
    unambiguously.
    """
    cutoff = parse_time(request.get("audit_at"))
    requested_email = normalize_email(request.get("email"))

    matches = {
        row["user_id"]
        for row in identities
        if normalize_email(row.get("email")) == requested_email
    }

    for event in audit:
        if event.get("field_name", "").casefold() != "email":
            continue

        event_time = parse_time(event.get("event_time"))

        if cutoff is not None and event_time is not None:
            if event_time > cutoff:
                continue

        old_email = normalize_email(event.get("old_value"))
        new_email = normalize_email(event.get("new_value"))

        if requested_email in (old_email, new_email):
            matches.add(event["user_id"])

    if len(matches) == 1:
        return next(iter(matches))

    return None


def evidence_path(manifest_row):
    """Resolve a manifest path relative to dataset/evidence."""
    relative = Path(manifest_row["file_path"])

    # Manifest entries normally begin with "evidence/".
    if relative.parts and relative.parts[0].casefold() == "evidence":
        relative = Path(*relative.parts[1:])

    return EVIDENCE_ROOT / relative



def classify_request(request_text):
    text = (request_text or "").casefold()
    text = " ".join(text.split())

    # Requests that are explicitly not asking for deletion.
    non_deletion_phrases = (
        "marketing opt-out",
        "marketing opt out",
        "opt out of marketing",
        "stop marketing",
        "correct my",
        "correct my personal data",
        "rectify my",
        "access my data",
        "export my data",
        "download my data",
        "show me my data",
        "port my data",
    )

    if any(phrase in text for phrase in non_deletion_phrases):
        return "NOT_APPLICABLE"

    # English deletion and deletion-verification language.
    deletion_phrases = (
        "delete",
        "deletion",
        "deleted",
        "deleting",
        "erase",
        "erasure",
        "erased",
        "remove",
        "removal",
        "purge",
        "wipe",
        "close my account",
        "close this account",
        "close the account",
        "account closure",
        "account is gone",
        "account no longer exists",
        "verify my account",
        "verify the account",
        "verify deletion",
        "verify deleted",
        "remaining profile",
        "personal details",
        "personal information",
        "identifying records",
        "old address",
        "earlier address",
        "search result",
        "search index",
        "backup",
        "restore",
        "tombstone",
        "data flow",
        "integration",
        "support conversation",
        "support message",
        "analytics",
        "privacy request",
        "account exists",
        "check the latest state",
        "confirm the profile is gone",
        "ensure no identifying records remain",
    )

    # Common non-English deletion terms in the supplied examples.
    multilingual_phrases = (
        "eliminar mi cuenta",
        "eliminación",
        "borrar mi cuenta",
        "supprimer mon compte",
        "suppression du compte",
        "suppression définitive",
        "effacer mes données",
        "削除",
    )

    if any(phrase in text for phrase in deletion_phrases + multilingual_phrases):
        return "DELETE"       
    return "REVIEW"


def search_evidence_for_case(request, user_id, data):
    """Find candidate evidence files containing the request's email aliases."""
    cutoff = parse_time(request.get("audit_at"))
    aliases = set()

    email = normalize_email(request.get("email"))
    if email:
        aliases.add(email)

    # Collect historical email aliases belonging to this identity.
    for event in data["audit"]:
        if event.get("user_id") != user_id:
            continue
        if event.get("field_name", "").casefold() != "email":
            continue

        event_time = parse_time(event.get("event_time"))
        if cutoff and event_time and event_time > cutoff:
            continue

        for value in (event.get("old_value"), event.get("new_value")):
            value = normalize_email(value)
            if value:
                aliases.add(value)

    matches = []
    supported_extensions = {".json", ".log", ".sql", ".txt"}

    for item in data["manifest"]:
        captured_at = parse_time(item.get("captured_at"))

        # Do not use evidence captured after this case's audit cutoff.
        if cutoff and captured_at and captured_at > cutoff:
            continue

        path = evidence_path(item)
        if path.suffix.casefold() not in supported_extensions:
            continue
        if not path.is_file():
            continue

        try:
            content = path.read_text(
                encoding="utf-8-sig",
                errors="replace"
            )
        except OSError:
            continue

        for line_number, line in enumerate(content.splitlines(), start=1):
            lowered = line.casefold()
            found = [alias for alias in aliases if alias in lowered]

            if found:
                matches.append({
                    "file_id": item.get("file_id", ""),
                    "file_path": str(path),
                    "line_number": line_number,
                    "aliases": found,
                    "line": line.strip()[:400],
                })

    return matches



def extract_json_evidence(request, data):
    cutoff = parse_time(request.get("audit_at"))
    user_id = resolve_identity(
        request, data["identities"], data["audit"]
    )

    aliases = {normalize_email(request.get("email"))}
    for event in data["audit"]:
        if event.get("user_id") != user_id:
            continue
        if event.get("field_name", "").casefold() != "email":
            continue

        event_time = parse_time(event.get("event_time"))
        if cutoff and event_time and event_time > cutoff:
            continue

        for value in (event.get("old_value"), event.get("new_value")):
            value = normalize_email(value)
            if value:
                aliases.add(value)

    aliases.discard("")
    results = {}

    def walk(node, path_parts, file_id):
        if isinstance(node, dict):
            # A resource is relevant if its own fields mention an alias.
            values = [
                str(value).casefold()
                for value in node.values()
                if isinstance(value, (str, int, float, bool))
            ]
            matched_aliases = [
                alias for alias in aliases
                if any(alias in value for value in values)
            ]

            resource_id = node.get("resource_id")
            if resource_id and matched_aliases:
                observed_at = node.get("observed_at")
                observed_time = parse_time(observed_at)

                if not cutoff or not observed_time or observed_time <= cutoff:
                    system = next(
                        (
                            part for part in path_parts
                            if part.endswith("_service")
                            or part.endswith("_platform")
                        ),
                        "unknown_system",
                    )

                    key = (file_id, system, str(resource_id))
                    results[key] = {
                        "file_id": file_id,
                        "system_id": system,
                        "resource_id": str(resource_id),
                        "observed_at": observed_at or "",
                        "matched_aliases": matched_aliases,
                        "fields": {
                            key: value
                            for key, value in node.items()
                            if not isinstance(value, (dict, list))
                        },
                    }

            for key, value in node.items():
                walk(value, path_parts + [key], file_id)

        elif isinstance(node, list):
            for item in node:
                walk(item, path_parts, file_id)

    for item in data["manifest"]:
        if Path(item["file_path"]).suffix.casefold() != ".json":
            continue

        captured_at = parse_time(item.get("captured_at"))
        if cutoff and captured_at and captured_at > cutoff:
            continue

        path = evidence_path(item)
        if not path.is_file():
            continue

        try:
            with path.open("r", encoding="utf-8-sig") as file:
                payload = json.load(file)
        except (OSError, json.JSONDecodeError):
            continue

        walk(payload, [], item.get("file_id", ""))

    return list(results.values())


def main():
    data = load_data()

    sample_by_id = {
        row["case_id"]: row
        for row in read_csv("sample_deletion_requests.csv")
    }

    for case_id in ("case_29", "case_30"):
        request = sample_by_id[case_id]
        print(f"\nStructured evidence: {case_id}")

        for record in extract_json_evidence(request, data):
            print(json.dumps(record, ensure_ascii=False))


    requests_by_id = {
        row["case_id"]: row
        for row in read_csv("sample_deletion_requests.csv")
    }

    identities_by_case = {
        case_id: resolve_identity(
            request,
            data["identities"],
            data["audit"]
        )
        for case_id, request in requests_by_id.items()
    }

    for case_id in ("case_10", "case_29", "case_30"):
        request = requests_by_id[case_id]
        user_id = identities_by_case[case_id]

        print(f"\nEvidence candidates for {case_id} ({user_id}):")
        matches = search_evidence_for_case(request, user_id, data)

        for match in matches[:20]:
            print(
                f'{match["file_id"]} '
                f'{match["file_path"]}:{match["line_number"]} '
                f'{match["line"]}'
            )

        print(f"Candidate matches: {len(matches)}")

    requests = data["requests"]
    identities = data["identities"]
    audit = data["audit"]
    manifest = data["manifest"]

    print(f"Repository: {ROOT}")
    print(f"Requests: {len(requests)}")
    print(f"Current identities: {len(identities)}")
    print(f"Audit events: {len(audit)}")
    print(f"System activities: {len(data['activities'])}")
    print(f"Deletion rules: {len(data['rules'])}")
    print(f"Evidence manifest entries: {len(manifest)}")

    missing_files = [
        row for row in manifest
        if not evidence_path(row).is_file()
    ]

    print(f"Evidence files missing: {len(missing_files)}")

    for row in missing_files[:10]:
        print(
            f"  MISSING {row['file_id']}: "
            f"{evidence_path(row)}"
        )

    print("\nSample identity-resolution diagnostics:")
    
    sample_requests = sorted(
        read_csv("sample_deletion_requests.csv"),
        key=lambda row: int(row["case_id"].split("_")[1])
    )

    for request in sample_requests:
        user_id = resolve_identity(request, identities, audit)
        intent = classify_request(request.get("request_text", ""))

        print(
            f"{request['case_id']}: "
            f"intent={intent}, "
            f"user_id={user_id or 'UNRESOLVED'}, "
            f"audit_at={request.get('audit_at', '')}"
        )

    print(
        "\nDiagnostic run only. "
        "No output.csv has been generated."
    )


if __name__ == "__main__":
    main()
